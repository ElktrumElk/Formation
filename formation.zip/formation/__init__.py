bl_info = {
    "name" : "Formation",
    "description" : "Takes the shape of an object in a particle form, with different functionality",
    "author" : "Elktrum Elk",
    "version" : (1, 0, 0),
    "blender" : (4, 3, 2),
    "location" : "Viewport add tab",
    "category" : "Node",
}

import bpy
import mathutils
import os

class Formation(bpy.types.Operator):
    bl_idname = "node.formation"
    bl_label = "Formation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        #initialize transformation_ node group
        def transformation__node_group():
            transformation_ = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Transformation'")

            transformation_.color_tag = 'NONE'
            transformation_.description = ""
            transformation_.default_group_node_width = 140
            


            #transformation_ interface
            #Socket Vector
            vector_socket = transformation_.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
            vector_socket.default_value = (0.0, 0.0, 0.0)
            vector_socket.min_value = -3.4028234663852886e+38
            vector_socket.max_value = 3.4028234663852886e+38
            vector_socket.subtype = 'NONE'
            vector_socket.attribute_domain = 'POINT'

            #Socket Vector
            vector_socket_1 = transformation_.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
            vector_socket_1.default_value = (0.0, 0.0, 0.0)
            vector_socket_1.min_value = -3.4028234663852886e+38
            vector_socket_1.max_value = 3.4028234663852886e+38
            vector_socket_1.subtype = 'NONE'
            vector_socket_1.attribute_domain = 'POINT'

            #Socket Vector
            vector_socket_2 = transformation_.interface.new_socket(name = "Vector", in_out='OUTPUT', socket_type = 'NodeSocketVector')
            vector_socket_2.default_value = (0.0, 0.0, 0.0)
            vector_socket_2.min_value = -3.4028234663852886e+38
            vector_socket_2.max_value = 3.4028234663852886e+38
            vector_socket_2.subtype = 'NONE'
            vector_socket_2.attribute_domain = 'POINT'

            #Socket Value
            value_socket = transformation_.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket.default_value = 1.2000000476837158
            value_socket.min_value = -10000.0
            value_socket.max_value = 10000.0
            value_socket.subtype = 'NONE'
            value_socket.attribute_domain = 'POINT'

            #Socket Value
            value_socket_1 = transformation_.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_1.default_value = 5.699999809265137
            value_socket_1.min_value = -10000.0
            value_socket_1.max_value = 10000.0
            value_socket_1.subtype = 'NONE'
            value_socket_1.attribute_domain = 'POINT'

            #Socket Value
            value_socket_2 = transformation_.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_2.default_value = 3.0
            value_socket_2.min_value = -10000.0
            value_socket_2.max_value = 10000.0
            value_socket_2.subtype = 'NONE'
            value_socket_2.attribute_domain = 'POINT'

            #Socket Value
            value_socket_3 = transformation_.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_3.default_value = 1.0
            value_socket_3.min_value = -10000.0
            value_socket_3.max_value = 10000.0
            value_socket_3.subtype = 'NONE'
            value_socket_3.attribute_domain = 'POINT'

            #Socket Value
            value_socket_4 = transformation_.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_4.default_value = 5.699999809265137
            value_socket_4.min_value = -10000.0
            value_socket_4.max_value = 10000.0
            value_socket_4.subtype = 'NONE'
            value_socket_4.attribute_domain = 'POINT'

            #Socket Value
            value_socket_5 = transformation_.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_5.default_value = 1.399999976158142
            value_socket_5.min_value = -10000.0
            value_socket_5.max_value = 10000.0
            value_socket_5.subtype = 'NONE'
            value_socket_5.attribute_domain = 'POINT'

            #Socket Vector
            vector_socket_3 = transformation_.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
            vector_socket_3.default_value = (7.799999713897705, 7.799999713897705, 7.799999713897705)
            vector_socket_3.min_value = -10000.0
            vector_socket_3.max_value = 10000.0
            vector_socket_3.subtype = 'NONE'
            vector_socket_3.attribute_domain = 'POINT'

            #Socket Vector
            vector_socket_4 = transformation_.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
            vector_socket_4.default_value = (7.799999713897705, 7.799999713897705, 7.799999713897705)
            vector_socket_4.min_value = -10000.0
            vector_socket_4.max_value = 10000.0
            vector_socket_4.subtype = 'NONE'
            vector_socket_4.attribute_domain = 'POINT'


            #initialize transformation_ nodes
            #node Group Output
            group_output = transformation_.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.is_active_output = True

            #node Group Input
            group_input = transformation_.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"

            #node Combine XYZ
            combine_xyz = transformation_.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz.name = "Combine XYZ"

            #node Math.001
            math_001 = transformation_.nodes.new("ShaderNodeMath")
            math_001.name = "Math.001"
            math_001.operation = 'POWER'
            math_001.use_clamp = False
            #Value_001
            math_001.inputs[1].default_value = 1.5

            #node Math.002
            math_002 = transformation_.nodes.new("ShaderNodeMath")
            math_002.name = "Math.002"
            math_002.operation = 'MULTIPLY'
            math_002.use_clamp = False

            #node Math.003
            math_003 = transformation_.nodes.new("ShaderNodeMath")
            math_003.name = "Math.003"
            math_003.operation = 'POWER'
            math_003.use_clamp = False
            #Value_001
            math_003.inputs[1].default_value = 0.5

            #node Math.004
            math_004 = transformation_.nodes.new("ShaderNodeMath")
            math_004.name = "Math.004"
            math_004.operation = 'MULTIPLY'
            math_004.use_clamp = False

            #node Math.005
            math_005 = transformation_.nodes.new("ShaderNodeMath")
            math_005.name = "Math.005"
            math_005.operation = 'POWER'
            math_005.use_clamp = False
            #Value_001
            math_005.inputs[1].default_value = 1.0

            #node Math.006
            math_006 = transformation_.nodes.new("ShaderNodeMath")
            math_006.name = "Math.006"
            math_006.operation = 'MULTIPLY'
            math_006.use_clamp = False

            #node Frame
            frame = transformation_.nodes.new("NodeFrame")
            frame.label = "Rotation "
            frame.name = "Frame"
            frame.label_size = 20
            frame.shrink = True

            #node Combine XYZ.001
            combine_xyz_001 = transformation_.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_001.name = "Combine XYZ.001"

            #node Math.007
            math_007 = transformation_.nodes.new("ShaderNodeMath")
            math_007.name = "Math.007"
            math_007.operation = 'POWER'
            math_007.use_clamp = False
            #Value_001
            math_007.inputs[1].default_value = 0.5

            #node Math.008
            math_008 = transformation_.nodes.new("ShaderNodeMath")
            math_008.name = "Math.008"
            math_008.operation = 'MULTIPLY'
            math_008.use_clamp = False

            #node Frame.001
            frame_001 = transformation_.nodes.new("NodeFrame")
            frame_001.name = "Frame.001"
            frame_001.label_size = 20
            frame_001.shrink = True

            #node Math.010
            math_010 = transformation_.nodes.new("ShaderNodeMath")
            math_010.name = "Math.010"
            math_010.operation = 'POWER'
            math_010.use_clamp = False
            #Value_001
            math_010.inputs[1].default_value = 0.5

            #node Math.011
            math_011 = transformation_.nodes.new("ShaderNodeMath")
            math_011.name = "Math.011"
            math_011.operation = 'MULTIPLY'
            math_011.use_clamp = False

            #node Math.012
            math_012 = transformation_.nodes.new("ShaderNodeMath")
            math_012.name = "Math.012"
            math_012.operation = 'POWER'
            math_012.use_clamp = False
            #Value_001
            math_012.inputs[1].default_value = 1.5

            #node Math.013
            math_013 = transformation_.nodes.new("ShaderNodeMath")
            math_013.name = "Math.013"
            math_013.operation = 'MULTIPLY'
            math_013.use_clamp = False

            #node Separate XYZ
            separate_xyz = transformation_.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz.name = "Separate XYZ"

            #node Separate XYZ.001
            separate_xyz_001 = transformation_.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_001.name = "Separate XYZ.001"




            #Set parents
            combine_xyz.parent = frame_001
            math_001.parent = frame_001
            math_002.parent = frame_001
            math_003.parent = frame
            math_004.parent = frame
            math_005.parent = frame_001
            math_006.parent = frame_001
            combine_xyz_001.parent = frame
            math_007.parent = frame
            math_008.parent = frame
            math_010.parent = frame
            math_011.parent = frame
            math_012.parent = frame_001
            math_013.parent = frame_001

            #Set locations
            group_output.location = (662.73583984375, 0.0)
            group_input.location = (-644.0238037109375, 0.0)
            combine_xyz.location = (-763.31494140625, -343.6475830078125)
            math_001.location = (-1046.7161865234375, -298.9685363769531)
            math_002.location = (-1222.2479248046875, -303.900634765625)
            math_003.location = (-940.8981323242188, 40.98014831542969)
            math_004.location = (-1104.9312744140625, 41.342376708984375)
            math_005.location = (-1043.0948486328125, -451.4228515625)
            math_006.location = (-1229.54443359375, -463.5948181152344)
            frame.location = (1074.6416015625, 437.6226806640625)
            combine_xyz_001.location = (-630.61767578125, 45.01049041748047)
            math_007.location = (-948.0201416015625, -117.07418060302734)
            math_008.location = (-1107.9732666015625, -112.46853637695312)
            frame_001.location = (1167.5133056640625, -206.533203125)
            math_010.location = (-939.6802978515625, 193.27406311035156)
            math_011.location = (-1103.71337890625, 185.73179626464844)
            math_012.location = (-1029.54638671875, -166.1004638671875)
            math_013.location = (-1221.5595703125, -147.3992919921875)
            separate_xyz.location = (-444.0238037109375, -134.06689453125)
            separate_xyz_001.location = (-399.5574951171875, 417.7034912109375)

            #Set dimensions
            group_output.width, group_output.height = 140.0, 100.0
            group_input.width, group_input.height = 140.0, 100.0
            combine_xyz.width, combine_xyz.height = 140.0, 100.0
            math_001.width, math_001.height = 140.0, 100.0
            math_002.width, math_002.height = 140.0, 100.0
            math_003.width, math_003.height = 140.0, 100.0
            math_004.width, math_004.height = 140.0, 100.0
            math_005.width, math_005.height = 140.0, 100.0
            math_006.width, math_006.height = 140.0, 100.0
            frame.width, frame.height = 675.3333740234375, 521.1666870117188
            combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
            math_007.width, math_007.height = 140.0, 100.0
            math_008.width, math_008.height = 140.0, 100.0
            frame_001.width, frame_001.height = 664.0, 515.3333129882812
            math_010.width, math_010.height = 140.0, 100.0
            math_011.width, math_011.height = 140.0, 100.0
            math_012.width, math_012.height = 140.0, 100.0
            math_013.width, math_013.height = 140.0, 100.0
            separate_xyz.width, separate_xyz.height = 140.0, 100.0
            separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0

            #initialize transformation_ links
            #math_002.Value -> math_001.Value
            transformation_.links.new(math_002.outputs[0], math_001.inputs[0])
            #math_004.Value -> math_003.Value
            transformation_.links.new(math_004.outputs[0], math_003.inputs[0])
            #math_012.Value -> combine_xyz.X
            transformation_.links.new(math_012.outputs[0], combine_xyz.inputs[0])
            #math_006.Value -> math_005.Value
            transformation_.links.new(math_006.outputs[0], math_005.inputs[0])
            #math_003.Value -> combine_xyz_001.Y
            transformation_.links.new(math_003.outputs[0], combine_xyz_001.inputs[1])
            #math_011.Value -> math_010.Value
            transformation_.links.new(math_011.outputs[0], math_010.inputs[0])
            #separate_xyz_001.X -> math_011.Value
            transformation_.links.new(separate_xyz_001.outputs[0], math_011.inputs[0])
            #separate_xyz.Z -> math_006.Value
            transformation_.links.new(separate_xyz.outputs[2], math_006.inputs[0])
            #math_008.Value -> math_007.Value
            transformation_.links.new(math_008.outputs[0], math_007.inputs[0])
            #math_007.Value -> combine_xyz_001.Z
            transformation_.links.new(math_007.outputs[0], combine_xyz_001.inputs[2])
            #separate_xyz.X -> math_013.Value
            transformation_.links.new(separate_xyz.outputs[0], math_013.inputs[0])
            #separate_xyz_001.Z -> math_008.Value
            transformation_.links.new(separate_xyz_001.outputs[2], math_008.inputs[0])
            #math_013.Value -> math_012.Value
            transformation_.links.new(math_013.outputs[0], math_012.inputs[0])
            #math_005.Value -> combine_xyz.Z
            transformation_.links.new(math_005.outputs[0], combine_xyz.inputs[2])
            #separate_xyz_001.Y -> math_004.Value
            transformation_.links.new(separate_xyz_001.outputs[1], math_004.inputs[0])
            #separate_xyz.Y -> math_002.Value
            transformation_.links.new(separate_xyz.outputs[1], math_002.inputs[0])
            #math_010.Value -> combine_xyz_001.X
            transformation_.links.new(math_010.outputs[0], combine_xyz_001.inputs[0])
            #math_001.Value -> combine_xyz.Y
            transformation_.links.new(math_001.outputs[0], combine_xyz.inputs[1])
            #group_input.Value -> math_011.Value
            transformation_.links.new(group_input.outputs[4], math_011.inputs[1])
            #group_input.Value -> math_004.Value
            transformation_.links.new(group_input.outputs[1], math_004.inputs[1])
            #group_input.Value -> math_002.Value
            transformation_.links.new(group_input.outputs[0], math_002.inputs[1])
            #group_input.Vector -> separate_xyz.Vector
            transformation_.links.new(group_input.outputs[6], separate_xyz.inputs[0])
            #group_input.Vector -> separate_xyz_001.Vector
            transformation_.links.new(group_input.outputs[7], separate_xyz_001.inputs[0])
            #group_input.Value -> math_006.Value
            transformation_.links.new(group_input.outputs[2], math_006.inputs[1])
            #group_input.Value -> math_013.Value
            transformation_.links.new(group_input.outputs[5], math_013.inputs[1])
            #group_input.Value -> math_008.Value
            transformation_.links.new(group_input.outputs[3], math_008.inputs[1])
            #combine_xyz.Vector -> group_output.Vector
            transformation_.links.new(combine_xyz.outputs[0], group_output.inputs[0])
            #combine_xyz.Vector -> group_output.Vector
            transformation_.links.new(combine_xyz.outputs[0], group_output.inputs[1])
            #combine_xyz_001.Vector -> group_output.Vector
            transformation_.links.new(combine_xyz_001.outputs[0], group_output.inputs[2])
            return transformation_

        transformation_ = transformation__node_group()

        #initialize duplication node group
        def duplication_node_group():
            duplication = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Duplication")

            duplication.color_tag = 'NONE'
            duplication.description = ""
            duplication.default_group_node_width = 140
            


            #duplication interface
            #Socket Geometry
            geometry_socket = duplication.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket.attribute_domain = 'POINT'

            #Socket Geometry
            geometry_socket_1 = duplication.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_1.attribute_domain = 'POINT'

            #Socket Geometry
            geometry_socket_2 = duplication.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_2.attribute_domain = 'POINT'

            #Socket Amount
            amount_socket = duplication.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketInt')
            amount_socket.default_value = 1
            amount_socket.min_value = 0
            amount_socket.max_value = 2147483647
            amount_socket.subtype = 'NONE'
            amount_socket.attribute_domain = 'POINT'

            #Socket Translation
            translation_socket = duplication.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector')
            translation_socket.default_value = (0.0, 0.0, 0.0)
            translation_socket.min_value = -3.4028234663852886e+38
            translation_socket.max_value = 3.4028234663852886e+38
            translation_socket.subtype = 'TRANSLATION'
            translation_socket.attribute_domain = 'POINT'

            #Socket Rotation
            rotation_socket = duplication.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation')
            rotation_socket.default_value = (0.0, 0.0, 0.0)
            rotation_socket.attribute_domain = 'POINT'

            #Socket Value
            value_socket_6 = duplication.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_6.default_value = 0.5
            value_socket_6.min_value = -10000.0
            value_socket_6.max_value = 10000.0
            value_socket_6.subtype = 'NONE'
            value_socket_6.attribute_domain = 'POINT'

            #Socket Value
            value_socket_7 = duplication.interface.new_socket(name = "Value", in_out='INPUT', socket_type = 'NodeSocketFloat')
            value_socket_7.default_value = -20.799999237060547
            value_socket_7.min_value = -10000.0
            value_socket_7.max_value = 10000.0
            value_socket_7.subtype = 'NONE'
            value_socket_7.attribute_domain = 'POINT'


            #initialize duplication nodes
            #node Group Output
            group_output_1 = duplication.nodes.new("NodeGroupOutput")
            group_output_1.name = "Group Output"
            group_output_1.is_active_output = True

            #node Group Input
            group_input_1 = duplication.nodes.new("NodeGroupInput")
            group_input_1.name = "Group Input"

            #node Duplicate Elements
            duplicate_elements = duplication.nodes.new("GeometryNodeDuplicateElements")
            duplicate_elements.name = "Duplicate Elements"
            duplicate_elements.domain = 'POINT'
            #Selection
            duplicate_elements.inputs[1].default_value = True

            #node Transform Geometry.001
            transform_geometry_001 = duplication.nodes.new("GeometryNodeTransform")
            transform_geometry_001.name = "Transform Geometry.001"
            transform_geometry_001.mode = 'COMPONENTS'

            #node Math.015
            math_015 = duplication.nodes.new("ShaderNodeMath")
            math_015.name = "Math.015"
            math_015.operation = 'POWER'
            math_015.use_clamp = False
            #Value_001
            math_015.inputs[1].default_value = -0.29999998211860657

            #node Math.016
            math_016 = duplication.nodes.new("ShaderNodeMath")
            math_016.name = "Math.016"
            math_016.operation = 'MULTIPLY'
            math_016.use_clamp = False





            #Set locations
            group_output_1.location = (468.70867919921875, 0.0)
            group_input_1.location = (-478.7087097167969, 0.0)
            duplicate_elements.location = (-93.8072509765625, 157.58444213867188)
            transform_geometry_001.location = (278.70867919921875, 97.2303466796875)
            math_015.location = (83.53546142578125, -138.10894775390625)
            math_016.location = (-278.7087097167969, -157.58441162109375)

            #Set dimensions
            group_output_1.width, group_output_1.height = 140.0, 100.0
            group_input_1.width, group_input_1.height = 140.0, 100.0
            duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
            transform_geometry_001.width, transform_geometry_001.height = 140.0, 100.0
            math_015.width, math_015.height = 140.0, 100.0
            math_016.width, math_016.height = 140.0, 100.0

            #initialize duplication links
            #duplicate_elements.Geometry -> transform_geometry_001.Geometry
            duplication.links.new(duplicate_elements.outputs[0], transform_geometry_001.inputs[0])
            #math_015.Value -> transform_geometry_001.Scale
            duplication.links.new(math_015.outputs[0], transform_geometry_001.inputs[3])
            #math_016.Value -> math_015.Value
            duplication.links.new(math_016.outputs[0], math_015.inputs[0])
            #group_input_1.Geometry -> duplicate_elements.Geometry
            duplication.links.new(group_input_1.outputs[0], duplicate_elements.inputs[0])
            #group_input_1.Translation -> transform_geometry_001.Translation
            duplication.links.new(group_input_1.outputs[2], transform_geometry_001.inputs[1])
            #group_input_1.Value -> math_016.Value
            duplication.links.new(group_input_1.outputs[4], math_016.inputs[0])
            #group_input_1.Rotation -> transform_geometry_001.Rotation
            duplication.links.new(group_input_1.outputs[3], transform_geometry_001.inputs[2])
            #group_input_1.Amount -> duplicate_elements.Amount
            duplication.links.new(group_input_1.outputs[1], duplicate_elements.inputs[2])
            #group_input_1.Value -> math_016.Value
            duplication.links.new(group_input_1.outputs[5], math_016.inputs[1])
            #transform_geometry_001.Geometry -> group_output_1.Geometry
            duplication.links.new(transform_geometry_001.outputs[0], group_output_1.inputs[0])
            #transform_geometry_001.Geometry -> group_output_1.Geometry
            duplication.links.new(transform_geometry_001.outputs[0], group_output_1.inputs[1])
            return duplication

        duplication = duplication_node_group()

        #initialize formation node group
        def formation_node_group():
            formation = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Formation")

            formation.color_tag = 'GEOMETRY'
            formation.description = "Forming objects together"
            formation.default_group_node_width = 140
            

            formation.is_modifier = True
            formation.is_tool = True
            formation.is_mode_object = False
            formation.is_mode_edit = False
            formation.is_mode_sculpt = False
            formation.is_type_curve = False
            formation.is_type_mesh = False
            formation.is_type_point_cloud = False

            #formation interface
            #Socket Geometry
            geometry_socket_3 = formation.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_3.attribute_domain = 'POINT'

            #Socket Geometry
            geometry_socket_4 = formation.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
            geometry_socket_4.attribute_domain = 'POINT'

            #Panel source
            source_panel = formation.interface.new_panel("source")
            #Socket Type
            type_socket = formation.interface.new_socket(name = "Type", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = source_panel)
            type_socket.attribute_domain = 'POINT'

            #Socket Target
            target_socket = formation.interface.new_socket(name = "Target", in_out='INPUT', socket_type = 'NodeSocketObject', parent = source_panel)
            target_socket.attribute_domain = 'POINT'


            #Panel shell
            shell_panel = formation.interface.new_panel("shell", default_closed=True)
            #Socket Shell Type
            shell_type_socket = formation.interface.new_socket(name = "Shell Type", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = shell_panel)
            shell_type_socket.attribute_domain = 'POINT'

            #Socket Shell Object
            shell_object_socket = formation.interface.new_socket(name = "Shell Object", in_out='INPUT', socket_type = 'NodeSocketObject', parent = shell_panel)
            shell_object_socket.attribute_domain = 'POINT'

            #Socket materail
            materail_socket = formation.interface.new_socket(name = "materail", in_out='INPUT', socket_type = 'NodeSocketMaterial', parent = shell_panel)
            materail_socket.attribute_domain = 'POINT'

            #Socket Enable DPS
            enable_dps_socket = formation.interface.new_socket(name = "Enable DPS", in_out='INPUT', socket_type = 'NodeSocketBool', parent = shell_panel)
            enable_dps_socket.default_value = False
            enable_dps_socket.attribute_domain = 'POINT'
            enable_dps_socket.description = "Distribut point on surface"

            #Socket Amount
            amount_socket_1 = formation.interface.new_socket(name = "Amount", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = shell_panel)
            amount_socket_1.default_value = 0.10000000149011612
            amount_socket_1.min_value = 0.0
            amount_socket_1.max_value = 100.0
            amount_socket_1.subtype = 'NONE'
            amount_socket_1.attribute_domain = 'POINT'
            amount_socket_1.description = "The density of the shell. (value should be atleast 0.1). Note you can increase the density depending on you System memory."

            #Socket Power
            power_socket = formation.interface.new_socket(name = "Power", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = shell_panel)
            power_socket.default_value = 0.7999999523162842
            power_socket.min_value = -10000.0
            power_socket.max_value = 10000.0
            power_socket.subtype = 'NONE'
            power_socket.attribute_domain = 'POINT'
            power_socket.description = "Increase the shell density. Makes it more visable."


            #Panel Object R/S
            object_r_s_panel = formation.interface.new_panel("Object R/S")
            #Socket Seed
            seed_socket = formation.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = object_r_s_panel)
            seed_socket.default_value = 1
            seed_socket.min_value = -10000
            seed_socket.max_value = 10000
            seed_socket.subtype = 'NONE'
            seed_socket.attribute_domain = 'POINT'

            #Socket Scale
            scale_socket = formation.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketVector', parent = object_r_s_panel)
            scale_socket.default_value = (1.0, 1.0, 1.0)
            scale_socket.min_value = -3.4028234663852886e+38
            scale_socket.max_value = 3.4028234663852886e+38
            scale_socket.subtype = 'XYZ'
            scale_socket.attribute_domain = 'POINT'

            #Socket Rotation
            rotation_socket_1 = formation.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketVector', parent = object_r_s_panel)
            rotation_socket_1.default_value = (-0.4999999701976776, 0.0, 0.0)
            rotation_socket_1.min_value = -10000.0
            rotation_socket_1.max_value = 10000.0
            rotation_socket_1.subtype = 'NONE'
            rotation_socket_1.attribute_domain = 'POINT'
            rotation_socket_1.description = "Rotate"

            #Socket Random Rotation
            random_rotation_socket = formation.interface.new_socket(name = "Random Rotation", in_out='INPUT', socket_type = 'NodeSocketBool', parent = object_r_s_panel)
            random_rotation_socket.default_value = False
            random_rotation_socket.attribute_domain = 'POINT'
            random_rotation_socket.description = "Enable random rotation"

            #Socket Min
            min_socket = formation.interface.new_socket(name = "Min", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = object_r_s_panel)
            min_socket.default_value = 0.0
            min_socket.min_value = -3.4028234663852886e+38
            min_socket.max_value = 3.4028234663852886e+38
            min_socket.subtype = 'NONE'
            min_socket.attribute_domain = 'POINT'

            #Socket Max
            max_socket = formation.interface.new_socket(name = "Max", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = object_r_s_panel)
            max_socket.default_value = 1.0
            max_socket.min_value = -3.4028234663852886e+38
            max_socket.max_value = 3.4028234663852886e+38
            max_socket.subtype = 'NONE'
            max_socket.attribute_domain = 'POINT'


            #Panel Transformation
            transformation_panel = formation.interface.new_panel("Transformation")
            #Socket Translation
            translation_socket_1 = formation.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector', parent = transformation_panel)
            translation_socket_1.default_value = (0.0, 0.0, 0.0)
            translation_socket_1.min_value = -3.4028234663852886e+38
            translation_socket_1.max_value = 3.4028234663852886e+38
            translation_socket_1.subtype = 'TRANSLATION'
            translation_socket_1.attribute_domain = 'POINT'

            #Socket object location
            object_location_socket = formation.interface.new_socket(name = "object location", in_out='INPUT', socket_type = 'NodeSocketBool', parent = transformation_panel)
            object_location_socket.default_value = False
            object_location_socket.attribute_domain = 'POINT'

            #Socket Rotate: X
            rotate__x_socket = formation.interface.new_socket(name = "Rotate: X", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            rotate__x_socket.default_value = 5.699999809265137
            rotate__x_socket.min_value = -10000.0
            rotate__x_socket.max_value = 10000.0
            rotate__x_socket.subtype = 'NONE'
            rotate__x_socket.attribute_domain = 'POINT'

            #Socket Y
            y_socket = formation.interface.new_socket(name = "Y", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            y_socket.default_value = 5.699999809265137
            y_socket.min_value = -10000.0
            y_socket.max_value = 10000.0
            y_socket.subtype = 'NONE'
            y_socket.attribute_domain = 'POINT'

            #Socket Z
            z_socket = formation.interface.new_socket(name = "Z", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            z_socket.default_value = 1.0
            z_socket.min_value = -10000.0
            z_socket.max_value = 10000.0
            z_socket.subtype = 'NONE'
            z_socket.attribute_domain = 'POINT'

            #Socket Rotation
            rotation_socket_2 = formation.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            rotation_socket_2.default_value = -0.5
            rotation_socket_2.min_value = -10000.0
            rotation_socket_2.max_value = 10000.0
            rotation_socket_2.subtype = 'NONE'
            rotation_socket_2.attribute_domain = 'POINT'

            #Socket Scale: x
            scale__x_socket = formation.interface.new_socket(name = "Scale: x", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            scale__x_socket.default_value = 1.399999976158142
            scale__x_socket.min_value = -10000.0
            scale__x_socket.max_value = 10000.0
            scale__x_socket.subtype = 'NONE'
            scale__x_socket.attribute_domain = 'POINT'

            #Socket Y
            y_socket_1 = formation.interface.new_socket(name = "Y", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            y_socket_1.default_value = 1.2000000476837158
            y_socket_1.min_value = -10000.0
            y_socket_1.max_value = 10000.0
            y_socket_1.subtype = 'NONE'
            y_socket_1.attribute_domain = 'POINT'

            #Socket Z
            z_socket_1 = formation.interface.new_socket(name = "Z", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            z_socket_1.default_value = 3.0
            z_socket_1.min_value = -10000.0
            z_socket_1.max_value = 10000.0
            z_socket_1.subtype = 'NONE'
            z_socket_1.attribute_domain = 'POINT'

            #Socket Scale
            scale_socket_1 = formation.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = transformation_panel)
            scale_socket_1.default_value = 7.800000190734863
            scale_socket_1.min_value = -10000.0
            scale_socket_1.max_value = 10000.0
            scale_socket_1.subtype = 'NONE'
            scale_socket_1.attribute_domain = 'POINT'


            #Panel Duplication
            duplication_panel = formation.interface.new_panel("Duplication")
            #Socket Translation
            translation_socket_2 = formation.interface.new_socket(name = "Translation", in_out='INPUT', socket_type = 'NodeSocketVector', parent = duplication_panel)
            translation_socket_2.default_value = (0.0, 0.0, 0.0)
            translation_socket_2.min_value = -3.4028234663852886e+38
            translation_socket_2.max_value = 3.4028234663852886e+38
            translation_socket_2.subtype = 'TRANSLATION'
            translation_socket_2.attribute_domain = 'POINT'

            #Socket Rotation
            rotation_socket_3 = formation.interface.new_socket(name = "Rotation", in_out='INPUT', socket_type = 'NodeSocketRotation', parent = duplication_panel)
            rotation_socket_3.default_value = (0.0, 0.0, 0.0)
            rotation_socket_3.attribute_domain = 'POINT'

            #Socket Duplicate Amount
            duplicate_amount_socket = formation.interface.new_socket(name = "Duplicate Amount", in_out='INPUT', socket_type = 'NodeSocketInt', parent = duplication_panel)
            duplicate_amount_socket.default_value = 0
            duplicate_amount_socket.min_value = 0
            duplicate_amount_socket.max_value = 1
            duplicate_amount_socket.subtype = 'FACTOR'
            duplicate_amount_socket.attribute_domain = 'POINT'
            duplicate_amount_socket.description = "Duplicate the object"

            #Socket D Scale
            d_scale_socket = formation.interface.new_socket(name = "D Scale", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = duplication_panel)
            d_scale_socket.default_value = 0.07000000029802322
            d_scale_socket.min_value = 0.0
            d_scale_socket.max_value = 10.0
            d_scale_socket.subtype = 'NONE'
            d_scale_socket.attribute_domain = 'POINT'
            d_scale_socket.description = "Scale the duplicaton"



            #initialize formation nodes
            #node Group Input
            group_input_2 = formation.nodes.new("NodeGroupInput")
            group_input_2.name = "Group Input"

            #node Group Output
            group_output_2 = formation.nodes.new("NodeGroupOutput")
            group_output_2.name = "Group Output"
            group_output_2.hide = True
            group_output_2.is_active_output = True

            #node Join Geometry
            join_geometry = formation.nodes.new("GeometryNodeJoinGeometry")
            join_geometry.name = "Join Geometry"
            join_geometry.hide = True

            #node UV Sphere
            uv_sphere = formation.nodes.new("GeometryNodeMeshUVSphere")
            uv_sphere.name = "UV Sphere"
            #Segments
            uv_sphere.inputs[0].default_value = 12
            #Rings
            uv_sphere.inputs[1].default_value = 349
            #Radius
            uv_sphere.inputs[2].default_value = 0.8999999761581421

            #node Merge by Distance
            merge_by_distance = formation.nodes.new("GeometryNodeMergeByDistance")
            merge_by_distance.name = "Merge by Distance"
            merge_by_distance.mode = 'CONNECTED'
            #Selection
            merge_by_distance.inputs[1].default_value = True

            #node Instance on Points
            instance_on_points = formation.nodes.new("GeometryNodeInstanceOnPoints")
            instance_on_points.name = "Instance on Points"
            #Selection
            instance_on_points.inputs[1].default_value = True
            #Pick Instance
            instance_on_points.inputs[3].default_value = False
            #Instance Index
            instance_on_points.inputs[4].default_value = 0
            #Scale
            instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)

            #node Transform Geometry
            transform_geometry = formation.nodes.new("GeometryNodeTransform")
            transform_geometry.name = "Transform Geometry"
            transform_geometry.mode = 'COMPONENTS'

            #node Math
            math = formation.nodes.new("ShaderNodeMath")
            math.name = "Math"
            math.operation = 'POWER'
            math.use_clamp = False
            #Value_001
            math.inputs[1].default_value = -1.0

            #node Math.009
            math_009 = formation.nodes.new("ShaderNodeMath")
            math_009.name = "Math.009"
            math_009.operation = 'DIVIDE'
            math_009.use_clamp = False
            #Value_001
            math_009.inputs[1].default_value = 1.0

            #node Object Info
            object_info = formation.nodes.new("GeometryNodeObjectInfo")
            object_info.name = "Object Info"
            object_info.transform_space = 'ORIGINAL'
            #As Instance
            object_info.inputs[1].default_value = False

            #node Menu Switch
            menu_switch = formation.nodes.new("GeometryNodeMenuSwitch")
            menu_switch.name = "Menu Switch"
            menu_switch.active_index = 1
            menu_switch.data_type = 'GEOMETRY'
            menu_switch.enum_items.clear()
            menu_switch.enum_items.new("Select")
            menu_switch.enum_items[0].description = "Select an object with the drop pen"
            menu_switch.enum_items.new("Default")
            menu_switch.enum_items[1].description = "Default(sphere)"

            #node Menu Switch.001
            menu_switch_001 = formation.nodes.new("GeometryNodeMenuSwitch")
            menu_switch_001.name = "Menu Switch.001"
            menu_switch_001.active_index = 1
            menu_switch_001.data_type = 'GEOMETRY'
            menu_switch_001.enum_items.clear()
            menu_switch_001.enum_items.new("Default")
            menu_switch_001.enum_items[0].description = ""
            menu_switch_001.enum_items.new("Select")
            menu_switch_001.enum_items[1].description = ""

            #node Join Geometry.002
            join_geometry_002 = formation.nodes.new("GeometryNodeJoinGeometry")
            join_geometry_002.name = "Join Geometry.002"

            #node Join Geometry.003
            join_geometry_003 = formation.nodes.new("GeometryNodeJoinGeometry")
            join_geometry_003.name = "Join Geometry.003"

            #node Join Geometry.004
            join_geometry_004 = formation.nodes.new("GeometryNodeJoinGeometry")
            join_geometry_004.name = "Join Geometry.004"

            #node Join Geometry.005
            join_geometry_005 = formation.nodes.new("GeometryNodeJoinGeometry")
            join_geometry_005.name = "Join Geometry.005"

            #node Math.014
            math_014 = formation.nodes.new("ShaderNodeMath")
            math_014.name = "Math.014"
            math_014.operation = 'ADD'
            math_014.use_clamp = False
            #Value_001
            math_014.inputs[1].default_value = 0.0

            #node Group Input.001
            group_input_001 = formation.nodes.new("NodeGroupInput")
            group_input_001.name = "Group Input.001"

            #node Frame.002
            frame_002 = formation.nodes.new("NodeFrame")
            frame_002.label = "Duplication"
            frame_002.name = "Frame.002"
            frame_002.label_size = 20
            frame_002.shrink = True

            #node UV Sphere.001
            uv_sphere_001 = formation.nodes.new("GeometryNodeMeshUVSphere")
            uv_sphere_001.name = "UV Sphere.001"
            #Segments
            uv_sphere_001.inputs[0].default_value = 12
            #Rings
            uv_sphere_001.inputs[1].default_value = 349
            #Radius
            uv_sphere_001.inputs[2].default_value = 0.8999999761581421

            #node Set Material
            set_material = formation.nodes.new("GeometryNodeSetMaterial")
            set_material.name = "Set Material"
            #Selection
            set_material.inputs[1].default_value = True

            #node Group Input.002
            group_input_002 = formation.nodes.new("NodeGroupInput")
            group_input_002.name = "Group Input.002"

            #node Object Info.001
            object_info_001 = formation.nodes.new("GeometryNodeObjectInfo")
            object_info_001.name = "Object Info.001"
            object_info_001.transform_space = 'ORIGINAL'
            #As Instance
            object_info_001.inputs[1].default_value = False

            #node Group Input.003
            group_input_003 = formation.nodes.new("NodeGroupInput")
            group_input_003.name = "Group Input.003"

            #node Math.017
            math_017 = formation.nodes.new("ShaderNodeMath")
            math_017.name = "Math.017"
            math_017.operation = 'ADD'
            math_017.use_clamp = False
            #Value_001
            math_017.inputs[1].default_value = 0.0

            #node Group
            group = formation.nodes.new("GeometryNodeGroup")
            group.name = "Group"
            group.node_tree = transformation_

            #node Group.001
            group_001 = formation.nodes.new("GeometryNodeGroup")
            group_001.name = "Group.001"
            group_001.node_tree = duplication

            #node Transform Geometry.001
            transform_geometry_001_1 = formation.nodes.new("GeometryNodeTransform")
            transform_geometry_001_1.name = "Transform Geometry.001"
            transform_geometry_001_1.mode = 'COMPONENTS'
            #Translation
            transform_geometry_001_1.inputs[1].default_value = (0.0, 0.0, 0.0)
            #Rotation
            transform_geometry_001_1.inputs[2].default_value = (0.0, 0.0, 0.0)

            #node Distribute Points on Faces
            distribute_points_on_faces = formation.nodes.new("GeometryNodeDistributePointsOnFaces")
            distribute_points_on_faces.name = "Distribute Points on Faces"
            distribute_points_on_faces.distribute_method = 'RANDOM'
            distribute_points_on_faces.use_legacy_normal = False
            #Selection
            distribute_points_on_faces.inputs[1].default_value = True
            #Seed
            distribute_points_on_faces.inputs[6].default_value = 0

            #node Group Input.004
            group_input_004 = formation.nodes.new("NodeGroupInput")
            group_input_004.name = "Group Input.004"

            #node Object Info.002
            object_info_002 = formation.nodes.new("GeometryNodeObjectInfo")
            object_info_002.name = "Object Info.002"
            object_info_002.transform_space = 'RELATIVE'
            if "Armature" in bpy.data.objects:
                object_info_002.inputs[0].default_value = bpy.data.objects["Armature"]
            #As Instance
            object_info_002.inputs[1].default_value = False

            #node Switch
            switch = formation.nodes.new("GeometryNodeSwitch")
            switch.name = "Switch"
            switch.input_type = 'VECTOR'

            #node Combine XYZ
            combine_xyz_1 = formation.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz_1.name = "Combine XYZ"

            #node Separate XYZ
            separate_xyz_1 = formation.nodes.new("ShaderNodeSeparateXYZ")
            separate_xyz_1.name = "Separate XYZ"

            #node Random Value
            random_value = formation.nodes.new("FunctionNodeRandomValue")
            random_value.name = "Random Value"
            random_value.data_type = 'FLOAT'
            #ID
            random_value.inputs[7].default_value = 0

            #node Switch.001
            switch_001 = formation.nodes.new("GeometryNodeSwitch")
            switch_001.name = "Switch.001"
            switch_001.input_type = 'VECTOR'

            #node Switch.002
            switch_002 = formation.nodes.new("GeometryNodeSwitch")
            switch_002.name = "Switch.002"
            switch_002.input_type = 'GEOMETRY'




            #Set parents
            group_input_001.parent = frame_002
            group_001.parent = frame_002

            #Set locations
            group_input_2.location = (-3131.459716796875, -1781.3009033203125)
            group_output_2.location = (3052.060546875, -58.516231536865234)
            join_geometry.location = (2883.91455078125, -61.89205551147461)
            uv_sphere.location = (-1445.7626953125, -579.171142578125)
            merge_by_distance.location = (10.201701164245605, -67.04984283447266)
            instance_on_points.location = (2162.46044921875, -111.3888931274414)
            transform_geometry.location = (-263.71929931640625, 19.380828857421875)
            math.location = (-427.2699279785156, -634.3970336914062)
            math_009.location = (-622.0072631835938, -764.906005859375)
            object_info.location = (-1888.02978515625, 92.89443969726562)
            menu_switch.location = (-1055.08935546875, -521.9078369140625)
            menu_switch_001.location = (-775.0723876953125, 292.3360595703125)
            join_geometry_002.location = (-663.1065063476562, -174.39202880859375)
            join_geometry_003.location = (-388.7107238769531, 270.7751159667969)
            join_geometry_004.location = (1464.2598876953125, -104.11083221435547)
            join_geometry_005.location = (1569.678466796875, -246.0008544921875)
            math_014.location = (-2269.066162109375, -2162.95263671875)
            group_input_001.location = (839.9619140625, -1283.902099609375)
            frame_002.location = (-1351.994384765625, -351.7286376953125)
            uv_sphere_001.location = (-1873.67724609375, 457.7359924316406)
            set_material.location = (-1345.721435546875, 163.48719787597656)
            group_input_002.location = (-2809.2568359375, 87.7535171508789)
            object_info_001.location = (-2572.173095703125, 372.47705078125)
            group_input_003.location = (1220.0584716796875, -428.7359313964844)
            math_017.location = (-2262.31298828125, -1969.8990478515625)
            group.location = (-1378.3751220703125, -1809.09033203125)
            group_001.location = (1126.7210693359375, -1258.652587890625)
            transform_geometry_001_1.location = (-2157.1396484375, 388.9202575683594)
            distribute_points_on_faces.location = (1726.5684814453125, 13.794856071472168)
            group_input_004.location = (1417.0933837890625, 635.377685546875)
            object_info_002.location = (-982.9265747070312, -86.94510650634766)
            switch.location = (-588.9366455078125, 44.522003173828125)
            combine_xyz_1.location = (1804.48779296875, -327.0065002441406)
            separate_xyz_1.location = (1556.84130859375, -388.1216125488281)
            random_value.location = (1739.67529296875, -606.7390747070312)
            switch_001.location = (2005.5689697265625, -300.51116943359375)
            switch_002.location = (2008.0238037109375, 76.79732513427734)

            #Set dimensions
            group_input_2.width, group_input_2.height = 140.0, 100.0
            group_output_2.width, group_output_2.height = 140.0, 100.0
            join_geometry.width, join_geometry.height = 140.0, 100.0
            uv_sphere.width, uv_sphere.height = 140.0, 100.0
            merge_by_distance.width, merge_by_distance.height = 100.0, 100.0
            instance_on_points.width, instance_on_points.height = 140.0, 100.0
            transform_geometry.width, transform_geometry.height = 140.0, 100.0
            math.width, math.height = 140.0, 100.0
            math_009.width, math_009.height = 140.0, 100.0
            object_info.width, object_info.height = 140.0, 100.0
            menu_switch.width, menu_switch.height = 140.0, 100.0
            menu_switch_001.width, menu_switch_001.height = 140.0, 100.0
            join_geometry_002.width, join_geometry_002.height = 140.0, 100.0
            join_geometry_003.width, join_geometry_003.height = 140.0, 100.0
            join_geometry_004.width, join_geometry_004.height = 140.0, 100.0
            join_geometry_005.width, join_geometry_005.height = 140.0, 100.0
            math_014.width, math_014.height = 140.0, 100.0
            group_input_001.width, group_input_001.height = 116.574462890625, 100.0
            frame_002.width, frame_002.height = 484.6666259765625, 740.5001220703125
            uv_sphere_001.width, uv_sphere_001.height = 140.0, 100.0
            set_material.width, set_material.height = 140.0, 100.0
            group_input_002.width, group_input_002.height = 140.0, 100.0
            object_info_001.width, object_info_001.height = 140.0, 100.0
            group_input_003.width, group_input_003.height = 140.0, 100.0
            math_017.width, math_017.height = 140.0, 100.0
            group.width, group.height = 140.0, 100.0
            group_001.width, group_001.height = 140.0, 100.0
            transform_geometry_001_1.width, transform_geometry_001_1.height = 140.0, 100.0
            distribute_points_on_faces.width, distribute_points_on_faces.height = 170.0, 100.0
            group_input_004.width, group_input_004.height = 140.0, 100.0
            object_info_002.width, object_info_002.height = 140.0, 100.0
            switch.width, switch.height = 140.0, 100.0
            combine_xyz_1.width, combine_xyz_1.height = 140.0, 100.0
            separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
            random_value.width, random_value.height = 140.0, 100.0
            switch_001.width, switch_001.height = 140.0, 100.0
            switch_002.width, switch_002.height = 140.0, 100.0

            #initialize formation links
            #join_geometry.Geometry -> group_output_2.Geometry
            formation.links.new(join_geometry.outputs[0], group_output_2.inputs[0])
            #transform_geometry.Geometry -> merge_by_distance.Geometry
            formation.links.new(transform_geometry.outputs[0], merge_by_distance.inputs[0])
            #instance_on_points.Instances -> join_geometry.Geometry
            formation.links.new(instance_on_points.outputs[0], join_geometry.inputs[0])
            #math.Value -> merge_by_distance.Distance
            formation.links.new(math.outputs[0], merge_by_distance.inputs[2])
            #group.Vector -> transform_geometry.Scale
            formation.links.new(group.outputs[0], transform_geometry.inputs[3])
            #group.Vector -> transform_geometry.Rotation
            formation.links.new(group.outputs[2], transform_geometry.inputs[2])
            #math_009.Value -> math.Value
            formation.links.new(math_009.outputs[0], math.inputs[0])
            #group_input_2.Target -> object_info.Object
            formation.links.new(group_input_2.outputs[2], object_info.inputs[0])
            #object_info.Geometry -> menu_switch.Select
            formation.links.new(object_info.outputs[4], menu_switch.inputs[1])
            #uv_sphere.Mesh -> menu_switch.Default
            formation.links.new(uv_sphere.outputs[0], menu_switch.inputs[2])
            #group_input_2.Type -> menu_switch.Menu
            formation.links.new(group_input_2.outputs[1], menu_switch.inputs[0])
            #join_geometry_002.Geometry -> transform_geometry.Geometry
            formation.links.new(join_geometry_002.outputs[0], transform_geometry.inputs[0])
            #menu_switch.Output -> join_geometry_002.Geometry
            formation.links.new(menu_switch.outputs[0], join_geometry_002.inputs[0])
            #menu_switch_001.Output -> join_geometry_003.Geometry
            formation.links.new(menu_switch_001.outputs[0], join_geometry_003.inputs[0])
            #group_001.Geometry -> join_geometry_005.Geometry
            formation.links.new(group_001.outputs[0], join_geometry_005.inputs[0])
            #group_input_2.Scale -> math_014.Value
            formation.links.new(group_input_2.outputs[24], math_014.inputs[0])
            #group_001.Geometry -> join_geometry_004.Geometry
            formation.links.new(group_001.outputs[1], join_geometry_004.inputs[0])
            #set_material.Geometry -> menu_switch_001.Default
            formation.links.new(set_material.outputs[0], menu_switch_001.inputs[1])
            #uv_sphere_001.Mesh -> set_material.Geometry
            formation.links.new(uv_sphere_001.outputs[0], set_material.inputs[0])
            #group_input_2.materail -> set_material.Material
            formation.links.new(group_input_2.outputs[5], set_material.inputs[2])
            #group_input_002.Shell Type -> menu_switch_001.Menu
            formation.links.new(group_input_002.outputs[3], menu_switch_001.inputs[0])
            #transform_geometry_001_1.Geometry -> menu_switch_001.Select
            formation.links.new(transform_geometry_001_1.outputs[0], menu_switch_001.inputs[2])
            #group_input_002.Shell Object -> object_info_001.Object
            formation.links.new(group_input_002.outputs[4], object_info_001.inputs[0])
            #group_input_2.Rotation -> math_017.Value
            formation.links.new(group_input_2.outputs[20], math_017.inputs[0])
            #group_input_2.Rotate: X -> group.Value
            formation.links.new(group_input_2.outputs[17], group.inputs[4])
            #group_input_2.Y -> group.Value
            formation.links.new(group_input_2.outputs[18], group.inputs[1])
            #group_input_2.Y -> group.Value
            formation.links.new(group_input_2.outputs[22], group.inputs[0])
            #math_014.Value -> group.Vector
            formation.links.new(math_014.outputs[0], group.inputs[6])
            #math_017.Value -> group.Vector
            formation.links.new(math_017.outputs[0], group.inputs[7])
            #group_input_2.Z -> group.Value
            formation.links.new(group_input_2.outputs[23], group.inputs[2])
            #group_input_2.Scale: x -> group.Value
            formation.links.new(group_input_2.outputs[21], group.inputs[5])
            #group_input_2.Z -> group.Value
            formation.links.new(group_input_2.outputs[19], group.inputs[3])
            #merge_by_distance.Geometry -> group_001.Geometry
            formation.links.new(merge_by_distance.outputs[0], group_001.inputs[0])
            #group_input_001.Translation -> group_001.Translation
            formation.links.new(group_input_001.outputs[25], group_001.inputs[2])
            #group.Vector -> group_001.Value
            formation.links.new(group.outputs[1], group_001.inputs[4])
            #group_input_001.Rotation -> group_001.Rotation
            formation.links.new(group_input_001.outputs[26], group_001.inputs[3])
            #group_input_2.Duplicate Amount -> group_001.Amount
            formation.links.new(group_input_2.outputs[27], group_001.inputs[1])
            #group_input_001.D Scale -> group_001.Value
            formation.links.new(group_input_001.outputs[28], group_001.inputs[5])
            #join_geometry_005.Geometry -> instance_on_points.Instance
            formation.links.new(join_geometry_005.outputs[0], instance_on_points.inputs[2])
            #object_info_001.Geometry -> transform_geometry_001_1.Geometry
            formation.links.new(object_info_001.outputs[4], transform_geometry_001_1.inputs[0])
            #group_input_002.Scale -> transform_geometry_001_1.Scale
            formation.links.new(group_input_002.outputs[10], transform_geometry_001_1.inputs[3])
            #join_geometry_004.Geometry -> distribute_points_on_faces.Mesh
            formation.links.new(join_geometry_004.outputs[0], distribute_points_on_faces.inputs[0])
            #group_input_004.Amount -> distribute_points_on_faces.Density
            formation.links.new(group_input_004.outputs[7], distribute_points_on_faces.inputs[4])
            #switch.Output -> transform_geometry.Translation
            formation.links.new(switch.outputs[0], transform_geometry.inputs[1])
            #group_input_002.Translation -> switch.False
            formation.links.new(group_input_002.outputs[15], switch.inputs[1])
            #group_input_002.object location -> switch.Switch
            formation.links.new(group_input_002.outputs[16], switch.inputs[0])
            #separate_xyz_1.X -> combine_xyz_1.X
            formation.links.new(separate_xyz_1.outputs[0], combine_xyz_1.inputs[0])
            #separate_xyz_1.Y -> combine_xyz_1.Y
            formation.links.new(separate_xyz_1.outputs[1], combine_xyz_1.inputs[1])
            #separate_xyz_1.Z -> combine_xyz_1.Z
            formation.links.new(separate_xyz_1.outputs[2], combine_xyz_1.inputs[2])
            #group_input_003.Rotation -> separate_xyz_1.Vector
            formation.links.new(group_input_003.outputs[11], separate_xyz_1.inputs[0])
            #random_value.Value -> switch_001.True
            formation.links.new(random_value.outputs[1], switch_001.inputs[2])
            #combine_xyz_1.Vector -> switch_001.False
            formation.links.new(combine_xyz_1.outputs[0], switch_001.inputs[1])
            #switch_001.Output -> instance_on_points.Rotation
            formation.links.new(switch_001.outputs[0], instance_on_points.inputs[5])
            #group_input_003.Random Rotation -> switch_001.Switch
            formation.links.new(group_input_003.outputs[12], switch_001.inputs[0])
            #group_input_003.Min -> random_value.Min
            formation.links.new(group_input_003.outputs[13], random_value.inputs[2])
            #group_input_003.Max -> random_value.Max
            formation.links.new(group_input_003.outputs[14], random_value.inputs[3])
            #group_input_003.Seed -> random_value.Seed
            formation.links.new(group_input_003.outputs[9], random_value.inputs[8])
            #join_geometry_004.Geometry -> switch_002.False
            formation.links.new(join_geometry_004.outputs[0], switch_002.inputs[1])
            #switch_002.Output -> instance_on_points.Points
            formation.links.new(switch_002.outputs[0], instance_on_points.inputs[0])
            #distribute_points_on_faces.Points -> switch_002.True
            formation.links.new(distribute_points_on_faces.outputs[0], switch_002.inputs[2])
            #group_input_004.Enable DPS -> switch_002.Switch
            formation.links.new(group_input_004.outputs[6], switch_002.inputs[0])
            #group_input_002.Power -> math_009.Value
            formation.links.new(group_input_002.outputs[8], math_009.inputs[0])
            #merge_by_distance.Geometry -> join_geometry_004.Geometry
            formation.links.new(merge_by_distance.outputs[0], join_geometry_004.inputs[0])
            #join_geometry_003.Geometry -> join_geometry_005.Geometry
            formation.links.new(join_geometry_003.outputs[0], join_geometry_005.inputs[0])
            #object_info_002.Location -> switch.True
            formation.links.new(object_info_002.outputs[1], switch.inputs[2])
            type_socket.default_value = 'Select'
            shell_type_socket.default_value = 'Default'
            return formation

        formation = formation_node_group()

        name = bpy.context.object.name
        obj = bpy.data.objects[name]
        mod = obj.modifiers.new(name = "Formation", type = 'NODES')
        mod.node_group = formation
        return {'FINISHED'}

def menu_func(self, context):
    self.layout.operator(Formation.bl_idname)

def register():
    bpy.utils.register_class(Formation)
    bpy.types.OBJECT_MT_modifier_add.append(menu_func)

def unregister():
    bpy.utils.unregister_class(Formation)
    bpy.types.OBJECT_MT_modifier_add.remove(menu_func)

if __name__ == "__main__":
    register()
